---
name: academic-writing
description: Draft, revise, and review clear, natural academic Indonesian for theses, research reports, literature reviews, methods, results, and conclusions. Use for academic rewriting, rephrasing, language reviews, original-versus-revised comparisons, or applying a supplied thesis writing reference. Preserve technical meaning, evidence, citations, and necessary English terminology while removing awkward formality, abstract phrasing, and formulaic contrasts. Follow an explicitly requested language for other academic work.
---

# academic writing

## Establish the target

Write natural academic prose that a reader can understand without unpacking the wording. Use a formal, explanatory register with ordinary precise verbs and concrete research objects. Include the detail needed to understand and inspect the claim.

Judge the argument before polishing its sentences. For every passage, establish the reader question it answers, the level at which its claim is true, the evidence it needs, and why it belongs in this section. A sentence can be accurate and cited yet irrelevant, repetitive, or misleading in context. Remove or relocate it when appropriate instead of rescuing it with smoother language, more detail, or another citation. Apply this judgment across the entire authorized scope. Treat highlighted examples as evidence of a writing pattern, not the boundaries of the problem.

Treat previously accepted revisions as a minimum quality floor. The user's prior revision table was judged passable, with room for improvement. Keep improving clarity and naturalness without inflating the text or changing its scientific meaning. Avoid presenting that table or its sentences as ideal models.

Follow the current request and latest corrections first, then the manuscript's conventions and any supplied reference. Use Indonesian by default for this user's Indonesian academic writing. Preserve another language when requested. Keep thesis-specific terminology within its own project.

Read [examples.md](references/examples.md) for calibration before substantial rewriting. Read [thesis-workflow.md](references/thesis-workflow.md) for chapter-level work, use of a friend's thesis reference, or any work on the user's agent-based operational-analysis thesis, including its punctuation and terminology rules.

## 1. Recover the meaning before editing

Read the passage and enough surrounding text to identify:

- The paragraph's purpose and central claim.
- The research object, action, or finding the reader needs to understand.
- Its evidence, attribution, uncertainty, and relevant citation.
- The population, unit, period, condition, comparison baseline, and exception that affect interpretation.

Preserve facts, calculations, citations, research scope, and uncertainty. Resolve an ambiguous technical relationship from available sources before rewriting it. If the ambiguity remains, preserve it or flag the smallest necessary question separately. Avoid making an unsupported claim more persuasive through smoother wording.

Check the scope of every claim, whatever its subject. Distinguish a general concept or shared property, a documented characteristic of a particular object, a local research choice, and an observed finding. A true statement about one instance does not establish that it is distinctive, exclusive, or caused by that instance. Check what the wording and placement imply about methods, data, concepts, tools, organizations, cases, and results alike. Use a subject that matches the evidence and the intended claim. Broaden, narrow, relocate, or remove the statement as needed. Do not add a defensive disclaimer merely to preserve an irrelevant distinction.

Retain a modifier such as “larger,” “automatic,” or “advanced” only when it identifies a relevant, supported distinction. Check what the source actually compared before asserting that a characteristic enables a capability. Preserve a genuinely supported distinction and explain a disagreement briefly when review is requested.

Use the smallest edit that actually improves the passage. Leave clear sentences alone. Reorganize a paragraph when local substitutions cannot fix its explanation.

## 2. Make the explanation concrete

Put the subject and operation early: “Penelitian ini membandingkan…”, “Agen membaca…”, “Setiap jawaban dinilai…”, or the relevant named object. Choose the form that fits the sentence rather than repeating one opening throughout.

Replace compressed abstractions with the actual relationship. Explain what is counted, compared, connected, provided, or tested. For example, describe reports containing different numbers of duration records before relying on a label such as “pembobotan observasi yang tidak seimbang.”

Prefer precise verbs such as menggunakan, menghasilkan, menghitung, membandingkan, menilai, mengukur, menyimpan, and menjelaskan. Retain specialized terminology when it makes a necessary distinction, and explain its local meaning where needed.

Choose active or passive voice according to the sentence's focus. Avoid third-person self-reference with “peneliti” as the narrative subject. Prefer the research, procedure, data, or result. Preserve real attribution and quoted wording; do not erase the source of an assurance to satisfy this preference.

Explain an unfamiliar concept through its definition, relevant mechanism, and local use when those steps help. For a case overview, describe the tested operation and distinguishing data condition. Add an example, calculation, or exception only when it resolves a likely misunderstanding or supports the paragraph's purpose. Before adding detail, identify the question it answers for the intended reader. Omit obvious mechanics, hypothetical alternatives, and explanations added only to make a subsection longer. Do not turn an editing concern into new manuscript prose.

## 3. Use natural Indonesian and appropriate technical English

Choose familiar academic Indonesian over bureaucratic or translated-sounding phrasing. Prefer “data yang telah dianonimkan” when it reads more naturally than a compressed construction. Avoid nominalizations and ornate synonyms that obscure a simple operation.

Retain established English technical terms when they are clearer or identify an exact concept. Use the manuscript's consistent choices for terms such as tool, tool call, prompt, input/output, array, context window, and reasoning. Avoid both mechanical translation and unnecessary English in otherwise ordinary Indonesian.

Explain an unfamiliar term at its first substantive use. Preserve exact identifiers and meaningful distinctions. Apply the institution's spelling, italics, acronym, and citation conventions. Avoid synonym rotation for variety when one accurate term is needed throughout.

## 4. Let the argument determine the structure

Give each paragraph one coherent job. Keep related clauses together; split a sentence when it carries separate definitions, procedures, findings, or limitations that become hard to follow. Use complete sentences with enough development, without imposing sentence-length quotas or a fixed paragraph template.

Let each paragraph stop at the last detail its explanation needs. Do not automatically add a summary or conclusion that restates what the reader can already infer. Keep an ending when it adds a necessary consequence, interpretation, qualification, or transition. A paragraph may end on a procedure, example, finding, or condition. Review this pattern across adjacent paragraphs without imposing sentence quotas or deleting all conclusions. This preference overrides generic advice to give every paragraph a concluding sentence.

Check each section's purpose before polishing a paragraph. Put definitions, background, research choices, procedures, findings, and interpretation where they serve the argument. A heading about a particular subject does not make every true statement about that subject relevant there. Explain shared material once at the appropriate level and avoid repeating it under individual items. Follow a supplied reference's subsection organization when requested. Do not use any subsection to fill space with generic descriptions, unrelated study details, or caveats that belong elsewhere.

Use transitions only for an actual relationship: sequence, comparison, qualification, or supported consequence. Keep the comparison objects identifiable. For comparisons involving several factors, state what changes and what stays fixed in separate, readable sentences when needed. Remove introductions, roadmaps, and closing sentences that only announce the discussion's importance or repeat its content.

State the claim directly. Remove the staged “not X but Y” pattern and equivalents such as “bukan X, melainkan Y,” “tidak hanya X, tetapi juga Y,” and “bukan sekadar X.” Check consecutive sentences for the same rhetorical construction. State the relevant facts and their actual relationship instead.

Preserve scientifically necessary negatives, absence of evidence, failed conditions, and genuine comparisons. Avoid replacing every contrast with an unqualified positive claim. Keep necessary caveats where they change interpretation and consolidate repeated caveats where they add no information. State the actual procedure without inventing an unused alternative to deny. Do not append disclaimers about every possible validation, optimization, or omitted component.

Remove unsupported importance claims, exaggerated praise, vague “Hal ini menunjukkan” conclusions, and filler about future potential. Retain supported interpretation, useful synthesis, and clear existing academic phrasing.

## 5. Protect the evidence

Keep each citation attached to the claim it supports after splitting or moving text. Preserve cited mechanisms and qualifications when shortening. Keep literature findings, local design choices, and experimental results distinguishable. Verify a new citation before adding it; do not transfer citations from a reference thesis without checking their support.

Audit citation coverage for substantive definitions, empirical or capability claims, generalizations, and methodological principles. Find evidence that supports the particular relationship being claimed. For a method, verify that relevant research uses a sufficiently comparable problem, procedure, unit, or outcome. For example, support an evaluation approach with research using an appropriate task, reference answer, comparison rule, or metric. Read the relevant source and explain only what it supports. A topical citation is insufficient, and one cited principle does not validate every local implementation detail. State research-specific operational choices clearly as choices, without citation stuffing or claiming they were copied from a source. Flag unsupported points for research outside the clean prose instead of manufacturing authority. Identify unresolved claims by their wording or location, including unsupported claims retained from the source rather than newly added.

Preserve association, uncertainty, and limits of observation. Avoid changing “berkaitan dengan” into a causal claim or “menunjukkan” into “membuktikan.” Use statistical significance only when a supported analysis establishes it. Identify an unsupported claim separately rather than inventing evidence or silently asserting a correction.

Check numbers, arithmetic, denominators, units, dates, labels, and rounding. Distinguish a percentage-point difference from a relative percentage change. Retain the population and comparison baseline needed to interpret the result. Do not add a missing operational rule merely because it seems plausible.

## 6. Review and deliver

Compare the revised passage with the source in two passes:

1. **Meaning and placement:** Check claims, scope, section ownership, conditions, uncertainty, attribution, citation support and coverage, numbers, units, technical objects, and cross-references. Confirm that shortening has not removed a necessary mechanism or limitation.
2. **Reading:** Check whether a reader can identify the subject, action, and relationship on the first reading. Remove unnecessary abstraction, awkward translation, excessive formality, repetition, staged contrasts, and added detail without a clear purpose.

Return the requested artifact: revised prose, a language review, or an original/revision comparison. Keep editorial notes and unresolved factual questions outside the clean replacement text. Preserve the requested format and scope. When editing a document, follow its document-editing workflow and verify that the saved artifact contains the intended changes. Turn feedback about a recurring pattern into a targeted scan across the authorized scope, rather than fixing only the highlighted sentence. Respect document-wide rules without treating a review request alone as permission to rewrite the whole document.

Use naturalness and precision as the standard. Avoid deliberate errors, artificial stylistic variation, claims about authorship, or promises about AI-detector outcomes.
