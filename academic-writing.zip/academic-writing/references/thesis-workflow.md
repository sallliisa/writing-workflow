# Thesis structure and local terminology

## Use a supplied thesis reference carefully

Read the user's friend's thesis when it is available in the current task. Extract useful habits: concrete subjects, definitions followed by relevant explanation, explicit research materials, orderly procedures, and comparisons between named objects. When asked to follow the reference, inspect its actual subsection order and the function of each subsection before revising. Map the current material to those functions instead of inventing new explanations or using the reference only as a loose style sample. Follow the current thesis's actual argument and institutional requirements.

Verify numerical claims, citations, and technical definitions independently before reusing them. Do not import the reference's datasets, models, findings, wording, errors, or unsupported interpretations. Keep quotations exact when quotation is required. If the reference is unavailable, work from the available passage and state that limitation only when it affects the requested comparison.

## Give each chapter a clear job

- **Introduction:** Establish the concrete problem, the gap the study addresses, its questions, and its actual scope. Tie benefits to contributions the design can support.
- **Literature review:** Define concepts needed later, explain their relevant operation, and connect them to the study. Keep published claims and local design choices distinguishable.
- **Methods:** Make inputs, actions, outputs, controlled conditions, and evaluation units traceable. Name the unit before totaling cases, combinations, or repetitions.
- **Results and discussion:** Report the finding before interpreting it. Keep relevant denominators and conditions visible. Use prose to explain a useful relationship beyond the table.
- **Conclusion:** Answer the research questions using the results. Tie each recommendation to a finding, limitation, or unresolved question.

Apply this progression flexibly. Preserve the requested chapter structure and keep a short subsection short when a single result and table reference complete its purpose.

## Apply the thesis-wide punctuation rule

Do not use semicolons anywhere in this thesis. Check prose, tables, captions, notes, and citation groupings. Rewrite the relationship with natural sentences, conjunctions, or an appropriate list rather than mechanically replacing every semicolon with a comma. This is a rule for this thesis, not a blanket prohibition for other academic work.

Protect source integrity when an experimental prompt, context excerpt, code fragment, or quotation contains a semicolon. Where a paraphrase is appropriate, label it accurately and preserve the meaning. Never alter an experimental artifact or quotation while presenting it as verbatim. If exact reproduction is required and conflicts with the punctuation ban, flag the specific conflict outside the manuscript rather than silently creating an exception or falsifying the source.

## Keep local terminology local

For the user's thesis about agent-based operational analysis, consult the current manuscript and latest corrections before applying the following choices:

- Prefer established technical terms such as tool, tool call, prompt, array, context window, and input/output when they identify the intended computing concept naturally.
- Use “konteks bisnis” instead of “paket konteks” throughout this thesis. Adjust the whole phrase and sentence as needed, including combinations such as “paket konteks bisnis.” Preserve the distinction between business context and a model's context window.
- Use “Evaluasi” or “evaluasi” rather than “evaluasi otomatis,” matching heading or sentence capitalization. Describe the actual procedure when necessary instead of adding an unneeded label.
- Avoid invented or awkward labels such as “sistem agen” when “agen” names the intended object. Keep a different term only when a real technical distinction requires it.
- Use “dokumen routing” for the document that routes an agent to the relevant references when that is its actual role. Preserve the distinction between that document and the broader konteks bisnis. Avoid replacing every mention of context or guidance with routing.
- Use “ketentuan jawaban” or “aturan format jawaban” when the passage describes answer requirements or formatting. Preserve a formal contract term when it identifies a genuinely different technical object.
- Use a stable name for each unit: a source-data row, a report, an incident, an action, a test case, an execution, a repetition, and a saved answer can represent different things. Confirm equivalence before replacing one term with another.
- Distinguish context made available from context actually read. Distinguish a final answer from a record of the steps that produced it. Use the evidence required by each claim.
- Keep exact field names, model names, labels, status values, and filenames where the reader needs to locate or distinguish them. Preserve the difference between false, null, absent, zero, and not applicable.

Treat these as document-specific decisions. Use another manuscript's definitions and the user's latest instructions for another project. Avoid global search-and-replace based only on an English/Indonesian word pair.

## Keep every subsection relevant and properly scoped

Apply the same judgment throughout the thesis, including descriptions of concepts, data, business context, research objects, procedures, evaluation, findings, and limitations. First identify what the subsection needs to establish. Retain a sentence only if it helps establish that point at the right level of detail. A fact does not belong merely because it mentions the subsection's subject or has a citation.

Separate shared background from characteristics of a particular instance, research decisions from established principles, and observed findings from broader interpretations. Check for implied uniqueness, causation, or generality that the evidence does not support. Avoid both attributing general properties to one item and extending an item-specific result to a whole class. Keep a real, supported distinction when it matters.

Explain shared information once in its proper location. Keep study procedures where they can be understood together, and state limitations where they affect interpretation. Remove obvious mechanics, incidental facts, and defensive explanations that do not answer a reader's likely question. Do not repeat them across sections or invent replacements to preserve paragraph length. For example, a general explanation of tool use does not become distinctive background merely by appearing under one model's name. Apply the same test to every other subject.

## Make comparison tables useful

Use the same relevant attributes for the items being compared, with actual verified values, units, dates, and conditions. Check that categories and measurement methods are comparable. Avoid promotional descriptions, artificial differences in presentation, and rows that merely restate each item's involvement in the study. A clear source line can carry table attribution without repeating “menurut dokumentasi” in each cell. Keep qualifications that affect the value's meaning.

For this thesis's model comparison table, preserve the specific corrections: use numerical context limits, token prices, and relevant benchmark scores already discussed in the thesis. Verify variants, price categories, and benchmark versions. Omit promotional “agent characteristics” and unnecessary “role in this research” rows. Treat this table as one application of the general comparison rule, not the focus of the thesis-wide review.

## Explain and support evaluation methods

Separate the published evaluation principle from the study's operational rules. Support consequential claims about task specification, reference answers, analytical correctness, and success metrics with verified relevant research. A comparable study can justify the approach without establishing that it used this thesis's exact JSON comparison rules.

Describe what the actual evaluator does, with verified units and denominators. Do not invent a separate JSON Schema validator or add a disclaimer about its absence. Keep exact-match rules, parsing failures, ordering, numeric comparison, and PASS/FAIL treatment in the appropriate methods discussion when required for reproducibility. Introduce the general concept in theory without duplicating the complete implementation there.

For a multi-factor comparison, explain each comparison in turn. Name the models compared under a fixed context condition, then describe how the same model is compared with and without business context. Do not rely on a dense “antarmodel ... antarkondisi” sentence to carry the whole design.

## Deliver the requested scope

For a local rewrite, return the revised passage. For a requested comparison table, keep each source quotation exact, identify its location if available, and supply a complete replacement. For a chapter review, separate language edits from factual, citation, and methodological questions. Mark unresolved issues briefly outside clean prose; do not silently resolve them by guessing.

Keep useful clear passages. Avoid producing a fixed number of changes, adding explanatory material to every row, or expanding the work into a full thesis rewrite when the user requested a limited edit.
