# Selective writing examples

Use these anonymized examples to learn an editing decision. Adapt the wording to the current passage and its evidence. Treat the accepted example as a passable baseline and continue improving when a clearer, equally accurate formulation is available. Avoid treating any example as a mandatory sentence template.

## Contents

- [Explain the data relationship](#explain-the-data-relationship)
- [Replace abstraction with its referent](#replace-abstraction-with-its-referent)
- [Name the evaluation unit](#name-the-evaluation-unit)
- [Keep technical English where it helps](#keep-technical-english-where-it-helps)
- [Remove the third-person narrator](#remove-the-third-person-narrator)
- [State the claim directly](#state-the-claim-directly)
- [Preserve the limits of a result](#preserve-the-limits-of-a-result)
- [Choose detail for the paragraph's purpose](#choose-detail-for-the-paragraph's-purpose)
- [Decide what belongs before rewriting](#decide-what-belongs-before-rewriting)
- [Keep observations at their supported scope](#keep-observations-at-their-supported-scope)
- [Separate the two comparisons](#separate-the-two-comparisons)
- [Remove an unneeded alternative](#remove-an-unneeded-alternative)

## Explain the data relationship

Compressed source:

> T1-C1 menguji pembobotan observasi yang tidak seimbang dan durasi null.

User-accepted baseline:

> T1-C1 menguji perhitungan rata-rata durasi transaksi dari beberapa laporan. Setiap laporan memiliki jumlah catatan durasi yang berbeda, dan terdapat catatan dengan durasi null.

Name the calculation first, then describe the relevant condition in the data. The reader should understand what differs among reports without unpacking “pembobotan observasi yang tidak seimbang.” Preserve the distinction between reports and their duration records. Add a rule for weighting or excluding null values only if the source establishes it and the paragraph needs it. Keep null distinct from zero and an absent record.

## Replace abstraction with its referent

Source:

> Komponen ini menjelaskan unit satu baris data dan hubungan yang digunakan dalam pengelompokan.

Possible revision:

> Komponen ini menjelaskan apa yang diwakili oleh satu baris data dan hubungan antarentitas yang digunakan untuk mengelompokkan data.

Keep a technical term such as “grain” if the surrounding argument needs it. Explain the represented object rather than multiplying abstract nouns.

## Name the evaluation unit

Source:

> Unit penilaian adalah satu jawaban akhir yang tersimpan untuk kasus, kombinasi model dan kondisi konteks, serta nomor pengulangan tertentu.

Possible revision:

> Setiap jawaban akhir yang tersimpan menjadi satu unit penilaian. Jawaban tersebut terkait dengan satu kasus, satu kombinasi model dan kondisi konteks, serta satu nomor pengulangan.

Split the definition from its identifiers when that makes the relationship easier to follow. Preserve all dimensions of the unit.

## Keep technical English where it helps

Source:

> Deskripsi fungsi dan masukan setiap operasi membantu agen memilih alat untuk langkah analisis yang diperlukan.

Possible revision in a thesis that uses these terms:

> Deskripsi fungsi dan parameter input setiap operasi membantu agen memilih tool yang sesuai untuk setiap langkah analisis.

Use the technical vocabulary established in the document. Avoid translating “tool,” “tool call,” “array,” “prompt,” or “context window” mechanically. Also avoid inserting English into ordinary Indonesian phrases where it adds nothing.

## Remove the third-person narrator

Source:

> Peneliti mengkurasi aturan sistem tentang populasi, satuan pengukuran, formula, pembulatan, dan kondisi kelulusan untuk menyusun jawaban acuan.

Possible revision when the sentence describes the procedure:

> Aturan sistem tentang populasi, satuan pengukuran, rumus, pembulatan, dan syarat kelulusan dirangkum untuk menyusun jawaban acuan.

Make the procedure or research object the subject. If attribution establishes who supplied or verified a fact, retain that attribution in a suitable form. A stylistic edit cannot turn an author's assurance into independently verified evidence.

## State the claim directly

Formulaic source:

> Pengulangan bukan memperluas jenis analisis, melainkan menambah pengamatan pada kasus yang sama.

Possible revision:

> Pengulangan menghasilkan lebih banyak jawaban untuk kasus yang sama. Jenis analisis yang diuji tetap terbatas pada kasus yang dipilih.

State both relevant facts directly. Keep their relationship clear without a staged correction.

## Preserve the limits of a result

Synthetic source:

> Model A memperoleh 18/20 PASS tanpa konteks dan 20/20 PASS dengan konteks. Hasil ini membuktikan bahwa konteks meningkatkan kemampuan model secara signifikan.

Possible revision if the source reports only these descriptive counts:

> Model A memperoleh 18/20 PASS tanpa konteks dan 20/20 PASS dengan konteks. Selisih tingkat keberhasilannya adalah 10 poin persentase.

Flag the unsupported causal or statistical claim separately when the task calls for review. A language edit should not add an inferential test, a causal mechanism, or a wider claim of capability. Preserve a supported interpretation when additional evidence actually establishes it.

## Choose detail for the paragraph's purpose

For a case overview, identify the tested operation and distinguishing data conditions. Reserve a worked calculation for the methods or results passage that explains the calculation. Include population, denominator, unit, date boundaries, exceptions, and rounding whenever their omission would change how a claim is understood. Avoid expanding every sentence into a complete technical specification.

## Decide what belongs before rewriting

Synthetic source in a subsection describing research data:

> Data penelitian disimpan dalam tabel. Tabel terdiri atas baris dan kolom.

The second sentence is generally true, but it may add nothing for the intended reader. Do not make it more elaborate or add a citation merely to keep it. Explain the actual data structure only when it matters to the analysis and is supported by the source.

The same judgment applies to a general explanation of tool use under a single model's heading, a study procedure inserted into a definition, or a limitation repeated after an unrelated finding. Identify the passage's purpose, claim scope, evidence, and placement before choosing to retain, rewrite, move, or remove it. Do not fix only the topic used in an example.

## Keep observations at their supported scope

Synthetic source:

> Pada tiga kasus yang diuji, semua jawaban sesuai dengan acuan. Metode ini menjamin ketepatan analisis operasional.

Possible revision when those three cases are the available evidence:

> Semua jawaban pada tiga kasus yang diuji sesuai dengan acuan.

The broader guarantee does not follow from the reported observations. Retain the supported result without adding a generic disclaimer. Preserve a broader interpretation only when other evidence supports it. Apply the same scope check to claims about data, procedures, concepts, organizations, tools, and other research objects.

## Separate the two comparisons

Source:

> Hasil dibandingkan antarmodel pada kondisi konteks yang sama dan antarkondisi konteks pada model yang sama.

Possible revision when the study compares two models with and without business context:

> Kinerja kedua model dibandingkan pada kondisi konteks bisnis yang sama. Untuk setiap model, hasil pengujian dengan konteks bisnis juga dibandingkan dengan hasil pengujian tanpa konteks bisnis.

Keep the comparison descriptive unless the design supports an inference about influence or causation. Name the models if the surrounding text does not make them clear.

## Remove an unneeded alternative

Source:

> Penilaian membandingkan struktur dan nilai JSON yang telah dibaca terhadap jawaban acuan, tanpa validator JSON Schema yang terpisah.

Possible revision when that comparison is the verified procedure:

> Penilaian membandingkan struktur dan nilai JSON dengan jawaban acuan.

Keep the actual procedure and omit the unraised alternative. Put any necessary parsing details in the methods passage that explains the comparison. Separately verify the methodological citation when the task requires justification. Do not replace the removed phrase with another disclaimer.
